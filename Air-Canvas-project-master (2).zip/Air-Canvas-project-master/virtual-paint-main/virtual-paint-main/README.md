# virtual-paint
This is a virtual painting python script bult using opencv and mediapipe

demonstration :- https://youtu.be/dwCaEFFXq74
